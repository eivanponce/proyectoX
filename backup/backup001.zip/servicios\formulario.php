<?php
	$completo = $_POST['contacto'];
	if($completo == "true"){
		$nombre = $_POST['f_nombre'];
		$apellidos = $_POST['f_apellidos'];
		$email = $_POST['f_email'];
		$telefono = $_POST['f_telefono'];
		$observaciones = $_POST['f_observaciones'];

		$asunto = "Solicitud de contacto web";
		$menaje = "Nombre completo: ".$nombre." ".$apellidos."Email: ".$email."Tel�fono: ".$telefono."Mensaje:".$observaciones;
					
	}else{
		$dato = $_POST['f_numeroOemail'];	

		$asunto = "Solicitud de cita previa";
		$menaje = "Tel�fono o email: ".$dato." Llamar o contactar lo antes posible";
			
	}

	if(mail('info@sotorodriguezabogados.es',$asunto,$menaje)){
		echo "Se ha enviado su solicitud correctamente.Le responderemos lo antes posible";
	}else{
		echo "No pudo enviarse sus datos, intentelo en otro momento.";
	}

?>