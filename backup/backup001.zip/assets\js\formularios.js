$(document).ready(function () {
    $("#btn_enviar_formulario").unbind().on("click", function (e) {
        e.preventDefault();

        var f_nombre = $("#f_nombre").val();
        var f_apellidos = $("#f_apellidos").val();
        var f_telefono = $("#f_telefono").val();
        var f_email = $("#f_email").val();
        var f_observaciones = $("#f_observaciones").val();

        if (f_nombre != null && f_nombre.length > 0 && !(/^\s+$/.test(f_nombre)) &&
                f_apellidos != null && f_apellidos.length > 0 && !(/^\s+$/.test(f_apellidos)) &&
                f_telefono != null && f_telefono.length > 0 && !(/^\s+$/.test(f_telefono)) &&
                f_email != null && f_email.length > 0 && !(/^\s+$/.test(f_email)) &&
                f_observaciones != null && f_observaciones.length > 0 && !(/^\s+$/.test(f_observaciones))) {
            $.post("/servicios/formulario.php", { contacto:"true",f_nombre: f_nombre, f_apellidos: f_apellidos, f_telefono: f_telefono, f_email: f_email, f_observaciones: f_observaciones })
                .done(function (data) {
                    if (data.indexOf("No pudo enviarse sus datos, intentelo en otro momento.") >= 0) {
                        $("#msg_contacto").css("background-color", "#F75B5B");
                        $("#msg_contacto").css("color", "white");
                    } else {
                        $("#msg_contacto").css("background-color", "#007A61");
                        $("#msg_contacto").css("color", "black");
                    }
                    $("#msg_contacto").html(data);
                    $("#msg_contacto").fadeIn(400).delay(4000).slideUp(400);
                });
        } else {
            $("#msg_contacto").css("background-color", "#F75B5B");
            $("#msg_contacto").css("color", "white");
            $("#msg_contacto").html("Debe rellenar todos los campos del formulario");
            $("#msg_contacto").fadeIn(400).delay(4000).slideUp(400);
        }
    });
    $("#btn_enviar_cita").unbind().on("click", function (e) {
        e.preventDefault();
        var f_numeroOemail = $("#f_numeroOemail").val();
      
        if (f_numeroOemail != null && f_numeroOemail.length > 0 && !(/^\s+$/.test(f_numeroOemail)) ) {
            $.post("/servicios/formulario.php", { contacto: "false", f_numeroOemail: f_numeroOemail })
                .done(function (data) {
                    if (data.indexOf("No pudo enviarse sus datos, intentelo en otro momento.") >= 0) {
                        $("#msg_cita").css("background-color", "#F75B5B");
                        $("#msg_cita").css("color", "white");
                    } else {
                        $("#msg_cita").css("background-color", "#007A61");
                        $("#msg_cita").css("color", "black");
                    }
                    $("#msg_cita").html(data);
                    $("#msg_cita").fadeIn(400).delay(4000).slideUp(400);
                });
        } else {
            $("#msg_cita").css("background-color", "#F75B5B");
            $("#msg_cita").css("color", "white");
            $("#msg_cita").html("Debe rellenar todos los campos del formulario");
            $("#msg_cita").fadeIn(400).delay(4000).slideUp(400);
        }
    });
});
